# Actual project > 2024-04-03 8:38pm
https://universe.roboflow.com/learning-fk4al/actual-project

Provided by a Roboflow user
License: CC BY 4.0

